{
    "success": true,
    "Users": [
        {
            "id": 3,
            "cliente_NOMBRE": "Bảo Khánh Đỗ",
            "cliente_ID": "gg_106263452150533879793",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 4,
            "cliente_NOMBRE": "Phúc Cola Team KTR",
            "cliente_ID": "gg_118003751567153802477",
            "cliente_DateExpired": "22-12-2026",
            "status": 1
        },
        {
            "id": 6,
            "cliente_NOMBRE": "Thư Ký Bigo",
            "cliente_ID": "gg_117479909469461690042",
            "cliente_DateExpired": "22-12-2025",
            "status": 1
        },
        {
            "id": 7,
            "cliente_NOMBRE": "YPG Gaming Miễn Phí Gaming",
            "cliente_ID": "gg_112856904905026318803",
            "cliente_DateExpired": "22-12-2026",
            "status": 1
        },
        {
            "id": 8,
            "cliente_NOMBRE": "Hữu Cường Miễn Phí NSND",
            "cliente_ID": "gg_104036191490514828222",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 9,
            "cliente_NOMBRE": "Capt.Valorous Miễn Phí Gaming",
            "cliente_ID": "gg_101831586738758140920",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 10,
            "cliente_NOMBRE": "Nonamilo Miễn Phí VNXX",
            "cliente_ID": "gg_103686642800479605216",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 11,
            "cliente_NOMBRE": "Skylar 2.0 Miễn Phí Gaming",
            "cliente_ID": "gg_110138644723647181361",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 12,
            "cliente_NOMBRE": "Choudhary Gaming Miễn Phí",
            "cliente_ID": "gg_111146039569353765907",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 13,
            "cliente_NOMBRE": "Hoài Kevin Miễn Phí NSND",
            "cliente_ID": "gg_107567296468393049840",
            "cliente_DateExpired": "22-01-2026",
            "status": 1
        },
        {
            "id": 14,
            "cliente_NOMBRE": "KTR GAMING (Dung) Miễn Phí",
            "cliente_ID": "gg_110127023831902098010",
            "cliente_DateExpired": "10-12-2027",
            "status": 1
        },
        {
            "id": 15,
            "cliente_NOMBRE": "FSG C-3 PH Gaming TV Miễn Phí",
            "cliente_ID": "gg_107731640693688812731",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 17,
            "cliente_NOMBRE": "Roth TK Gaming Miễn Phí ",
            "cliente_ID": "gg_1126741085952137344",
            "cliente_DateExpired": "22-12-2027",
            "status": 1
        },
        {
            "id": 18,
            "cliente_NOMBRE": "Tiến Nguyễn Miễn Phí VNXX",
            "cliente_ID": "gg_113947993593145316242",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 21,
            "cliente_NOMBRE": "Loui Nguyễn Miễn Phí NSND",
            "cliente_ID": "gg_102260588408030482530",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 22,
            "cliente_NOMBRE": "Nguyễn kiệt miễn Phí Vnxx",
            "cliente_ID": "gg_100697496998560334399",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 23,
            "cliente_NOMBRE": "Jimser Jumdana Miễn Phí Gaming",
            "cliente_ID": "gg_114836405436770143943",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 24,
            "cliente_NOMBRE": "Roth TK Gaming Miễn Phí ",
            "cliente_ID": "gg_112674108595213734480",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 25,
            "cliente_NOMBRE": "Nguyễn Đạt Sáo Diều Miễn Phí",
            "cliente_ID": "gg_111474626303292143865",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 26,
            "cliente_NOMBRE": "Sang",
            "cliente_ID": "gg_104443362290978772727",
            "cliente_DateExpired": "24-10-2025",
            "status": 1
        },
        {
            "id": 27,
            "cliente_NOMBRE": "Anh Điền miễn Phí KTR",
            "cliente_ID": "gg_111380425837584660057",
            "cliente_DateExpired": "24-12-2027",
            "status": 1
        },
        {
            "id": 28,
            "cliente_NOMBRE": "Trym mơ",
            "cliente_ID": "gg_109536964274447464403",
            "cliente_DateExpired": "01-04-2026",
            "status": 1
        },
        {
            "id": 29,
            "cliente_NOMBRE": "Nona",
            "cliente_ID": "gg_113118458685425827975",
            "cliente_DateExpired": "31-07-2025",
            "status": 1,
            "Client_VisibleSkin1": "1448",
            "Client_VisibleSkin2": "1435"
        },
        {
            "id": 30,
            "cliente_NOMBRE": "Sang Mic (NSND)",
            "cliente_ID": "gg_100822767016650531499",
            "cliente_DateExpired": "01-01-2026",
            "status": 1
        },
        {
            "id": 31,
            "cliente_NOMBRE": "trym mơ nona",
            "cliente_ID": "gg_115162172950237463238",
            "cliente_DateExpired": "26-12-2027",
            "status": 1
        },
        {
            "id": 32,
            "cliente_NOMBRE": "Hải dương xanh",
            "cliente_ID": "gg_113552720946097514417",
            "cliente_DateExpired": "14-01-2027",
            "status": 1
        },
        {
            "id": 35,
            "cliente_NOMBRE": "Kiên",
            "cliente_ID": "gg_107702673716448049022",
            "cliente_DateExpired": "10-10-2025",
            "status": 1
        },
        {
            "id": 44,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_114149799844221504705",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "31-01-2025",
            "status": 1
        },
        {
            "id": 46,
            "cliente_NOMBRE": "A điền ktr",
            "cliente_ID": "gg_116285763340476363159",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "31-12-2027",
            "status": 1
        },
        {
            "id": 47,
            "cliente_NOMBRE": "Phúc cola",
            "cliente_ID": "gg_110609623381341647352",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "31-12-2027",
            "status": 1
        },
        {
            "id": 49,
            "cliente_NOMBRE": "Linh com",
            "cliente_ID": "gg_114686565989332434392",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "24-04-2026",
            "status": 1
        },
        {
            "id": 50,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_110918492431698939554",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "26-01-2025",
            "status": 1
        },
        {
            "id": 51,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106895728404524239661",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-03-2026",
            "status": 1
        },
        {
            "id": 52,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_104277289286780173212",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "06-02-2025",
            "status": 1
        },
        {
            "id": 53,
            "cliente_NOMBRE": "Minh Cảnh",
            "cliente_ID": "gg_113910184521983399730",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "06-02-2025",
            "status": 1
        },
        {
            "id": 54,
            "cliente_NOMBRE": "Gã thợ hàn",
            "cliente_ID": "gg_111018830864357755793",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "12-02-2025",
            "status": 1
        },
        {
            "id": 55,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_113541578044886880454",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "12-05-2025",
            "status": 1
        },
        {
            "id": 56,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_117802254303824744839",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "20-02-2025",
            "status": 1
        },
        {
            "id": 57,
            "cliente_NOMBRE": "Viết minh",
            "cliente_ID": "gg_109421723777724498622",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "20-02-2025",
            "status": 1
        },
        {
            "id": 58,
            "cliente_NOMBRE": "Nước ngoài gaming",
            "cliente_ID": "gg_114612622926372470355",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "31-01-2026",
            "status": 1
        },
        {
            "id": 59,
            "cliente_NOMBRE": "Nước Ngoài GameMing",
            "cliente_ID": "gg_105802316784517175649",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-04-2026",
            "status": 1
        },
        {
            "id": 60,
            "cliente_NOMBRE": "Nước ngoài gaming",
            "cliente_ID": "gg_105987723042336457559",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "12-02-2026",
            "status": 1
        },
        {
            "id": 61,
            "cliente_NOMBRE": "Tuấn Cảnh",
            "cliente_ID": "gg_110036344307212067901",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "05-09-2027",
            "status": 1
        },
        {
            "id": 62,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_110135316318969654161",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "08-03-2025",
            "status": 1
        },
        {
            "id": 63,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_101114774367918713244",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "11-03-2025",
            "status": 1
        },
        {
            "id": 66,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_105317077107314865845",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "22-03-2025",
            "status": 1
        },
        {
            "id": 68,
            "cliente_NOMBRE": "Linhcomgaming",
            "cliente_ID": "gg_109239008740849824026",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "17-11-2027",
            "status": 1
        },
        {
            "id": 69,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_109847888398290363090",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "30-03-2025",
            "status": 1
        },
        {
            "id": 70,
            "cliente_NOMBRE": "Ngọc Hiếu",
            "cliente_ID": "gg_116107991982597352037",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "01-04-2025",
            "status": 1
        },
        {
            "id": 71,
            "cliente_NOMBRE": "Tresam mơ",
            "cliente_ID": "gg_116608819813747194320",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "01-04-2027",
            "status": 1
        },
        {
            "id": 73,
            "cliente_NOMBRE": "Tú Trần VNXX",
            "cliente_ID": "gg_108318737694256509415",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-09-2025",
            "status": 1
        },
        {
            "id": 74,
            "cliente_NOMBRE": "Min TV",
            "cliente_ID": "gg_112663765102223196310",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-02-2027",
            "status": 1
        },
        {
            "id": 75,
            "cliente_NOMBRE": "Quốc",
            "cliente_ID": "gg_103311760618802738662",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-04-2025",
            "status": 1
        },
        {
            "id": 79,
            "cliente_NOMBRE": "Thông trần ",
            "cliente_ID": "gg_109378771106296757618",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "18-02-2025",
            "status": 1
        },
        {
            "id": 81,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_103578705185423436075",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "22-04-2025",
            "status": 1
        },
        {
            "id": 83,
            "cliente_NOMBRE": "Nguyễn Văn Lương",
            "cliente_ID": "gg_117383548078209328527",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "26-04-2025",
            "status": 1
        },
        {
            "id": 85,
            "cliente_NOMBRE": "Nước ngoài",
            "cliente_ID": "gg_104002430602626749848",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "12-04-2025",
            "status": 1
        },
        {
            "id": 86,
            "cliente_NOMBRE": "Đỗ Việt",
            "cliente_ID": "gg_102593434906053835638",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "25-05-2025",
            "status": 1
        },
        {
            "id": 87,
            "cliente_NOMBRE": "Việt Đỗ",
            "cliente_ID": "gg_102593434906053835638",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "24-05-2025",
            "status": 1
        },
        {
            "id": 89,
            "cliente_NOMBRE": "Đỗ việt",
            "cliente_ID": "gg_111910346670147761104",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "31-05-2025",
            "status": 1
        },
        {
            "id": 93,
            "cliente_NOMBRE": "Phúc Cola",
            "cliente_ID": "gg_103203972441611171630",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "14-06-2027",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 98,
            "cliente_NOMBRE": "Vương Hiệp",
            "cliente_ID": "gg_105185534186261650014",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "18-06-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 108,
            "cliente_NOMBRE": "Nhất",
            "cliente_ID": "gg_100918123650635468087",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "30-06-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 112,
            "cliente_NOMBRE": "Vương Hiệp",
            "cliente_ID": "gg_100144211001863045317",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "06-07-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 115,
            "cliente_NOMBRE": "15 đô",
            "cliente_ID": "gg_106655648260315682064",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "09-01-2026",
            "cliente_sothang": "15",
            "status": 1
        },
        {
            "id": 119,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109834743839377776751",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "14-07-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 132,
            "cliente_NOMBRE": "Nước Ngoài",
            "cliente_ID": "gg_101391274890723093085",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "27-07-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 133,
            "cliente_NOMBRE": "Nước Ngoài",
            "cliente_ID": "gg_106072178063043233069",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "27-08-2025",
            "cliente_sothang": "13",
            "status": 1
        },
        {
            "id": 144,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102545615686616681095",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "08-08-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 153,
            "cliente_NOMBRE": "Thái Lan",
            "cliente_ID": "gg_102333848301925669968",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "12-02-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 154,
            "cliente_NOMBRE": "Văn Khoa",
            "cliente_ID": "gg_114333140049600864176",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "13-02-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 155,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_118207213677378096359",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "13-06-2025",
            "cliente_sothang": "10",
            "status": 1
        },
        {
            "id": 158,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108711490245063964166",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "14-02-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 159,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103263540007575166415",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "15-02-2025",
            "cliente_sothang": "6",
            "status": 1,
            "Client_VisibleSkin1": "1430"
        },
        {
            "id": 165,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117331898407360718919",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "18-08-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 169,
            "cliente_NOMBRE": "Tuấn trang",
            "cliente_ID": "gg_116942331384574528223",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "21-02-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 171,
            "cliente_NOMBRE": "Vân du",
            "cliente_ID": "gg_111555455387896820826",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "21-02-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 176,
            "cliente_NOMBRE": "Thanh Trường",
            "cliente_ID": "gg_109293209923880987285",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "27-04-2025",
            "cliente_sothang": "8",
            "status": 1
        },
        {
            "id": 178,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_115368838032648360228",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "29-01-2025",
            "cliente_sothang": "5",
            "status": 1
        },
        {
            "id": 180,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108899738345852259399",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "30-06-2025",
            "cliente_sothang": "10",
            "status": 1
        },
        {
            "id": 183,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108979874028895217638",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "03-03-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 188,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_100156984780822074705",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "01-09-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 189,
            "cliente_NOMBRE": "Tịnh Tâm",
            "cliente_ID": "gg_105972927745208150493",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "02-09-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 191,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117114913378176165913",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "02-09-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 206,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117160273723025578849",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "05-09-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 216,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112075803715069938167",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "06-03-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 222,
            "cliente_NOMBRE": "Huynh hoang",
            "cliente_ID": "gg_117505477148232292880",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateExpired": "07-09-2025",
            "cliente_sothang": "12",
            "status": 1
        },
        {
            "id": 250,
            "cliente_NOMBRE": "Pro",
            "cliente_ID": "gg_118288354968569428292",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-09-2024",
            "cliente_DateExpired": "17-03-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 251,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114168565759135537881",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-09-2024",
            "cliente_DateExpired": "17-02-2025",
            "cliente_sothang": "5",
            "status": 1
        },
        {
            "id": 257,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112897932706557009697",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-09-2024",
            "cliente_DateExpired": "22-03-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 265,
            "cliente_NOMBRE": "Nguyễn sơn",
            "cliente_ID": "gg_105327597556518929224",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-09-2024",
            "cliente_DateExpired": "26-03-2025",
            "cliente_sothang": "6",
            "status": 1
        },
        {
            "id": 266,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109870923480988231038",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "28-09-2024",
            "cliente_DateExpired": "28-03-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 267,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112197915400479523191",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "28-09-2024",
            "cliente_DateExpired": "28-01-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 272,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103348454430351848762",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-10-2024",
            "cliente_DateExpired": "01-10-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 82,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108624638305660672911",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-10-2024",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 84,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103372135953313079773",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-10-2024",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 103,
            "cliente_NOMBRE": "Kim Anh Trần",
            "cliente_ID": "gg_108237012575275378023",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-10-2024",
            "cliente_DateExpired": "06-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 104,
            "cliente_NOMBRE": "hòa store",
            "cliente_ID": "gg_103088727939855098384",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-10-2024",
            "cliente_DateExpired": "06-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 5,
            "cliente_NOMBRE": "Mạnh trương ktr",
            "cliente_ID": "gg_115973408891045447377",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-10-2024",
            "cliente_DateExpired": "13-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 77,
            "cliente_NOMBRE": "Bảo khánh",
            "cliente_ID": "gg_101107261260428950335",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-10-2024",
            "cliente_DateExpired": "13-10-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 97,
            "cliente_NOMBRE": "Thoại Hải Phòng",
            "cliente_ID": "gg_117372688738702868470",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-10-2024",
            "cliente_DateExpired": "17-02-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 120,
            "cliente_NOMBRE": "Abelha Tiktoker",
            "cliente_ID": "gg_100950823289926243218",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-10-2024",
            "cliente_DateExpired": "19-10-2025",
            "cliente_sothang": 12,
            "status": 1,
            "Client_VisibleSkin1": "1453",
            "Client_VisibleSkin2": "1454",
            "Client_VisibleSkin3": "1431"
        },
        {
            "id": 124,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_104462687214849756626",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "20-10-2024",
            "cliente_DateExpired": "20-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 221,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101923195030281824633",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "21-10-2024",
            "cliente_DateExpired": "21-02-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 236,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_105960414887506892360",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-10-2024",
            "cliente_DateExpired": "22-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 252,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109763373457325477113",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "23-10-2024",
            "cliente_DateExpired": "23-03-2025",
            "cliente_sothang": 5,
            "status": 1
        },
        {
            "id": 126,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114065218821219216351",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-10-2024",
            "cliente_DateExpired": "24-04-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 127,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112298207664355129981",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-10-2024",
            "cliente_DateExpired": "24-02-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 122,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_107630932088202857413",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-10-2024",
            "cliente_DateExpired": "24-03-2025",
            "cliente_sothang": 5,
            "status": 1
        },
        {
            "id": 129,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113194553266514485094",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-10-2024",
            "cliente_DateExpired": "25-01-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 255,
            "cliente_NOMBRE": "Danh",
            "cliente_ID": "gg_112644762779511544542",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-10-2024",
            "cliente_DateExpired": "26-01-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 275,
            "cliente_NOMBRE": "Bạn",
            "cliente_ID": "gg_107963835662752274796",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_sothang": "3",
            "cliente_DateExpired": "27-01-2025",
            "status": 1
        },
        {
            "id": 134,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_110709196028092138067",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "29-10-2024",
            "cliente_DateExpired": "29-01-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 258,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101282028202156112613",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "29-10-2024",
            "cliente_DateExpired": "29-03-2025",
            "cliente_sothang": 5,
            "status": 1
        },
        {
            "id": 135,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102473365105386750200",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-10-2024",
            "cliente_DateExpired": "31-01-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 259,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_111079565084414129753",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-10-2024",
            "cliente_DateExpired": "31-01-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 136,
            "cliente_NOMBRE": "Nước ngoài gaming",
            "cliente_ID": "gg_106754785944189391660",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-11-2024",
            "cliente_DateExpired": "01-02-2026",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 137,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_3339956056309746",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-11-2024",
            "cliente_DateExpired": "01-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 279,
            "cliente_NOMBRE": "เดียร์",
            "cliente_ID": "gg_106553121001176825495",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_sothang": "3",
            "cliente_DateExpired": "01-02-2025",
            "status": 1
        },
        {
            "id": 274,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102556662019188972592",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-11-2024",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 276,
            "cliente_NOMBRE": "Bá vinh",
            "cliente_ID": "gg_114158784334095315282",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-11-2024",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 271,
            "cliente_NOMBRE": "Trường Giang",
            "cliente_ID": "fb_111916164167591",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-11-2024",
            "cliente_DateExpired": "18-08-2025",
            "cliente_sothang": 9,
            "status": 1
        },
        {
            "id": 139,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_1410664229369114",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-11-2024",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 5,
            "status": 1
        },
        {
            "id": 281,
            "cliente_NOMBRE": "ลีลา",
            "cliente_ID": "gg_105532635697485650226",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_sothang": "3",
            "cliente_DateExpired": "04-02-2025",
            "status": 1
        },
        {
            "id": 140,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102074264571396629925",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-11-2024",
            "cliente_DateExpired": "05-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 141,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101942107527320840108",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-11-2024",
            "cliente_DateExpired": "05-11-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 1,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113022117565356522986",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-11-2024",
            "cliente_DateExpired": "06-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 2,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112378907515885474317",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-11-2024",
            "cliente_DateExpired": "06-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 65,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103328405471573866631",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-11-2024",
            "cliente_DateExpired": "06-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 102,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_100225062536142430870",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-11-2024",
            "cliente_DateExpired": "06-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 277,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_100594110339778198546",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-11-2024",
            "cliente_DateExpired": "06-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 278,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_105394103532671135813",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-11-2024",
            "cliente_DateExpired": "07-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 280,
            "cliente_NOMBRE": "Ha L",
            "cliente_ID": "gg_102905310441957172685",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-11-2024",
            "cliente_DateExpired": "07-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 76,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106261932137800752179",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "08-11-2024",
            "cliente_DateExpired": "08-03-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 142,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106353535830005737501",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "08-11-2024",
            "cliente_DateExpired": "08-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 143,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103787917785995258944",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-11-2024",
            "cliente_DateExpired": "11-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 16,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_115877473051794583399",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-11-2024",
            "cliente_DateExpired": "11-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 145,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_105342381551486796071",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-11-2024",
            "cliente_DateExpired": "12-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 146,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116566643303214288874",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-11-2024",
            "cliente_DateExpired": "12-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 67,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112336832909489074109",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-11-2024",
            "cliente_DateExpired": "12-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 148,
            "cliente_NOMBRE": "Jao",
            "cliente_ID": "fb_162840275517340",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-11-2024",
            "cliente_DateExpired": "13-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 118,
            "cliente_NOMBRE": "Văn tiến",
            "cliente_ID": "gg_117010425945318393307",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "14-11-2024",
            "cliente_DateExpired": "14-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 64,
            "cliente_NOMBRE": "Phương anh",
            "cliente_ID": "gg_114022377462853267292",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "15-11-2024",
            "cliente_DateExpired": "15-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 149,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108318455963281498166",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "15-11-2024",
            "cliente_DateExpired": "15-11-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 109,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_115059608901225723593",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "15-11-2024",
            "cliente_DateExpired": "15-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 110,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102977578854042998299",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "16-11-2024",
            "cliente_DateExpired": "16-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 111,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112843057328121507087",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-11-2024",
            "cliente_DateExpired": "17-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 150,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114440898312866272947",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-11-2024",
            "cliente_DateExpired": "17-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 151,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113145763644242139981",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "18-11-2024",
            "cliente_DateExpired": "18-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 152,
            "cliente_NOMBRE": "Mạnh khách",
            "cliente_ID": "gg_109923181758491388570",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-11-2024",
            "cliente_DateExpired": "19-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 166,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_107870240759325811525",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-11-2024",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 168,
            "cliente_NOMBRE": "Writnan Kempaopaoao",
            "cliente_ID": "gg_110394289158408223479",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-11-2024",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 207,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_2418876325091604",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-11-2024",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 235,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117533593492520885391",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-11-2024",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 172,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_104341290961499449195",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "23-11-2024",
            "cliente_DateExpired": "23-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 244,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116642815906833577984",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "23-11-2024",
            "cliente_DateExpired": "23-03-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 246,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_107488588424355334322",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-11-2024",
            "cliente_DateExpired": "24-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 282,
            "cliente_NOMBRE": "A dũng mobi",
            "cliente_ID": "gg_110241039065480332988",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-11-2024",
            "cliente_DateExpired": "24-11-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 286,
            "cliente_NOMBRE": "ลีลาวดี",
            "cliente_ID": "gg_103440856443696590413",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-11-2024",
            "cliente_DateExpired": "25-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 128,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_3010449725754247",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-11-2024",
            "cliente_DateExpired": "26-05-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 130,
            "cliente_NOMBRE": "Trym mơ ấn độ",
            "cliente_ID": "gg_116735932808132402457",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-11-2024",
            "cliente_DateExpired": "26-05-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 173,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_104505073231059749841",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-11-2024",
            "cliente_DateExpired": "26-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 198,
            "cliente_NOMBRE": "ลีลาวดีๆ",
            "cliente_ID": "gg_104068480313168039393",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "27-11-2024",
            "cliente_DateExpired": "27-02-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 256,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101760625386433301260",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "30-11-2024",
            "cliente_DateExpired": "30-04-2025",
            "cliente_sothang": 5,
            "status": 1
        },
        {
            "id": 88,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114822826882364061795",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-12-2024",
            "cliente_DateExpired": "01-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 179,
            "cliente_NOMBRE": "อยู่ที่เรา",
            "cliente_ID": "gg_102380254680423571354",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-12-2024",
            "cliente_DateExpired": "01-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 181,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109257426014720480284",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-12-2024",
            "cliente_DateExpired": "01-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 288,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113684599435763712053",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 289,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_100949399333918545623",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-06-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 174,
            "cliente_NOMBRE": "BsNinh Lan",
            "cliente_ID": "gg_109808189088342123994",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 182,
            "cliente_NOMBRE": "Văn sỹ",
            "cliente_ID": "gg_101088733930515927539",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 184,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_112375926908208042534",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 185,
            "cliente_NOMBRE": "Phước Thành",
            "cliente_ID": "gg_114691224211891291421",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-12-2024",
            "cliente_DateExpired": "02-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 187,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116132916690444114584",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-12-2024",
            "cliente_DateExpired": "03-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 190,
            "cliente_NOMBRE": "Nước ngoài trym mơ",
            "cliente_ID": "gg_109704168924948227137",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-12-2024",
            "cliente_DateExpired": "03-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 264,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_118027562154489287090",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-12-2024",
            "cliente_DateExpired": "03-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 293,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103746525752142144715",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-12-2024",
            "cliente_DateExpired": "05-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 295,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112422920688677282194",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-12-2024",
            "cliente_DateExpired": "05-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 296,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117656456044918153557",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-12-2024",
            "cliente_DateExpired": "05-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 297,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116090661141775600643",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-12-2024",
            "cliente_DateExpired": "06-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 298,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_105443364971384946199",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-12-2024",
            "cliente_DateExpired": "06-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 299,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117823193051245518330",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-12-2024",
            "cliente_DateExpired": "06-09-2025",
            "cliente_sothang": 9,
            "status": 1
        },
        {
            "id": 300,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_115944840139898167591",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-12-2024",
            "cliente_DateExpired": "06-12-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 138,
            "cliente_NOMBRE": "Công trứ",
            "cliente_ID": "gg_100458147262979445249",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-12-2024",
            "cliente_DateExpired": "07-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 161,
            "cliente_NOMBRE": "Lê sơn",
            "cliente_ID": "gg_115197461460878453239",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-12-2024",
            "cliente_DateExpired": "07-12-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 43,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_104703956644256768746",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-12-2024",
            "cliente_DateExpired": "07-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 192,
            "cliente_NOMBRE": "Vi",
            "cliente_ID": "gg_111703829582333259458",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "08-12-2024",
            "cliente_DateExpired": "08-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 193,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_118137726486706282130",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "08-12-2024",
            "cliente_DateExpired": "08-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 194,
            "cliente_NOMBRE": "บ่าวค้น6เดือน",
            "cliente_ID": "gg_107798477312312657205",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "10-12-2024",
            "cliente_DateExpired": "10-06-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 91,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_118385088240261542324",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-12-2024",
            "cliente_DateExpired": "11-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 196,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_118137137393049670456",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-12-2024",
            "cliente_DateExpired": "12-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 197,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117426565933724347632",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-12-2024",
            "cliente_DateExpired": "12-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 199,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102268246067367768422",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-12-2024",
            "cliente_DateExpired": "12-07-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 200,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_3432946070110997",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-12-2024",
            "cliente_DateExpired": "13-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 201,
            "cliente_NOMBRE": "Chung ruồi gaming",
            "cliente_ID": "gg_116963521155888329357",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "14-12-2024",
            "cliente_DateExpired": "14-12-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 204,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_5232674733434286",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "16-12-2024",
            "cliente_DateExpired": "16-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 205,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "fb_417681006084110",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-12-2024",
            "cliente_DateExpired": "17-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 208,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106114196315892487820",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-12-2024",
            "cliente_DateExpired": "17-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 210,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113624885439034749188",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-12-2024",
            "cliente_DateExpired": "19-04-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 211,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101535106081338727419",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-12-2024",
            "cliente_DateExpired": "19-03-2025",
            "cliente_sothang": 3,
            "status": 1,
            "Client_VisibleSkin1": "1447",
            "Client_VisibleSkin2": "1449",
            "Client_VisibleSkin3": "1450",
            "Client_VisibleSkin4": "1455",
            "Client_VisibleSkin5": "1458",
            "Client_VisibleSkin6": "1459"
        },
        {
            "id": 212,
            "cliente_NOMBRE": "Quốc Trường",
            "cliente_ID": "gg_117613589503326754872",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-12-2024",
            "cliente_DateExpired": "19-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 213,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_110713148010755666307",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "21-12-2024",
            "cliente_DateExpired": "21-01-2026",
            "cliente_sothang": 13,
            "status": 1
        },
        {
            "id": 36,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117140242799627712315",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-12-2024",
            "cliente_DateExpired": "22-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 37,
            "cliente_NOMBRE": "Vương Hiệp",
            "cliente_ID": "gg_109032220114766746947",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "23-12-2024",
            "cliente_DateExpired": "23-01-2026",
            "cliente_sothang": 13,
            "status": 1
        },
        {
            "id": 38,
            "cliente_NOMBRE": "Nước ngoài trym mơ noba",
            "cliente_ID": "gg_122095161170657672",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-12-2024",
            "cliente_DateExpired": "24-06-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 41,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106263203218070035844",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "24-12-2024",
            "cliente_DateExpired": "24-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 19,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_107840591796421085997",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-12-2024",
            "cliente_DateExpired": "25-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 20,
            "cliente_NOMBRE": "A Cương",
            "cliente_ID": "gg_115175668250663916478",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-12-2024",
            "cliente_DateExpired": "25-02-2026",
            "cliente_sothang": 14,
            "status": 1
        },
        {
            "id": 33,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112616792125497322728",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-12-2024",
            "cliente_DateExpired": "25-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 34,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_104117451654395414851",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "25-12-2024",
            "cliente_DateExpired": "25-07-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 96,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114983504675221819355",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-12-2024",
            "cliente_DateExpired": "26-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 99,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_116001639963366826442",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-12-2024",
            "cliente_DateExpired": "26-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 147,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103089103074852049899",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "26-12-2024",
            "cliente_DateExpired": "26-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 131,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_113095435019642252334",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "27-12-2024",
            "cliente_DateExpired": "27-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 156,
            "cliente_NOMBRE": "Mr Andre",
            "cliente_ID": "gg_102695833653188353825",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "27-12-2024",
            "cliente_DateExpired": "27-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 157,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101932698436374270990",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "28-12-2024",
            "cliente_DateExpired": "28-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 160,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113744955931672045180",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "28-12-2024",
            "cliente_DateExpired": "28-04-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 162,
            "cliente_NOMBRE": "Test",
            "cliente_ID": "11111111111111111111111",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "28-12-2024",
            "cliente_DateExpired": "28-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 164,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_113650650303839315691",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "29-12-2024",
            "cliente_DateExpired": "29-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 170,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116501158548899711300",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "30-12-2024",
            "cliente_DateExpired": "30-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 175,
            "cliente_NOMBRE": "Trym mơ",
            "cliente_ID": "gg_101411305134197418310",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "30-12-2024",
            "cliente_DateExpired": "30-12-2025",
            "cliente_sothang": 12,
            "status": 1
        },
        {
            "id": 177,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_116864018670989373956",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "30-12-2024",
            "cliente_DateExpired": "30-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 214,
            "cliente_NOMBRE": "Mai",
            "cliente_ID": "gg_110520952957970779429",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 39,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109624085258270628257",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-03-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 163,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_110799521145009417264",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 215,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106554775704055741351",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 218,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_107314615783548424453",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-07-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 219,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_116098858739965124196",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "31-12-2024",
            "cliente_DateExpired": "31-01-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 220,
            "cliente_NOMBRE": "Bình Minh",
            "cliente_ID": "gg_102031589526887706759",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-01-2025",
            "cliente_DateExpired": "01-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 223,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_105982483488463048894",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "01-01-2025",
            "cliente_DateExpired": "01-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 224,
            "cliente_NOMBRE": "Duong Gia Quy",
            "cliente_ID": "gg_116101846494232027162",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-01-2025",
            "cliente_DateExpired": "02-03-2026",
            "cliente_sothang": 14,
            "status": 1
        },
        {
            "id": 45,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_117915704208941837139",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-01-2025",
            "cliente_DateExpired": "02-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 225,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_109803261436131666443",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-01-2025",
            "cliente_DateExpired": "02-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 226,
            "cliente_NOMBRE": "Mạnh chung",
            "cliente_ID": "gg_103895797631538202200",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "02-01-2025",
            "cliente_DateExpired": "02-07-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 227,
            "cliente_NOMBRE": "Hiep",
            "cliente_ID": "gg_108357273504036929863",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-04-2026",
            "cliente_sothang": 15,
            "status": 1
        },
        {
            "id": 228,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116198119669014490798",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 229,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_101690154278360200356",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 230,
            "cliente_NOMBRE": "โตโต้",
            "cliente_ID": "gg_118318813856516977447",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 231,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_118059638898539701958",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 232,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_101820154507997094090",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "03-01-2025",
            "cliente_DateExpired": "03-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 72,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102738814955969700543",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-01-2025",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 233,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_115834600705906993477",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-01-2025",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 234,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_104256272410076506398",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-01-2025",
            "cliente_DateExpired": "04-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 237,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_115587061302662261356",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-01-2025",
            "cliente_DateExpired": "04-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 238,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_117419358071613620750",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "04-01-2025",
            "cliente_DateExpired": "04-08-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 90,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_110705439697874152400",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-01-2025",
            "cliente_DateExpired": "05-08-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 240,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_118133127450693000971",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-01-2025",
            "cliente_DateExpired": "05-05-2025",
            "cliente_sothang": 4,
            "status": 1
        },
        {
            "id": 241,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_100715729383025317830",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-01-2025",
            "cliente_DateExpired": "05-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 242,
            "cliente_NOMBRE": "noom tt",
            "cliente_ID": "gg_114927911113941532384",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "05-01-2025",
            "cliente_DateExpired": "05-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 92,
            "cliente_NOMBRE": "Bạch Xà",
            "cliente_ID": "gg_106083495379269838611",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "06-01-2025",
            "cliente_DateExpired": "06-07-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 101,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_112445714293208995907",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "07-01-2025",
            "cliente_DateExpired": "07-03-2026",
            "cliente_sothang": 14,
            "status": 1
        },
        {
            "id": 239,
            "cliente_NOMBRE": "Việt Nam ",
            "cliente_ID": "gg_116329279762514407737",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "08-01-2025",
            "cliente_DateExpired": "08-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 100,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108114025636451834978",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "09-01-2025",
            "cliente_DateExpired": "09-08-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 105,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_110718784081481868982",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "10-01-2025",
            "cliente_DateExpired": "10-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 243,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_102180425084290741778",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "10-01-2025",
            "cliente_DateExpired": "10-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 245,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116678157008625206577",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-01-2025",
            "cliente_DateExpired": "29-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 106,
            "cliente_NOMBRE": "Nước Ngoài free 1 month",
            "cliente_ID": "gg_100710934892537524361",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-01-2025",
            "cliente_DateExpired": "11-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 107,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_108947521984917131577",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "11-01-2025",
            "cliente_DateExpired": "11-08-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 195,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_110137031296682427761",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "12-01-2025",
            "cliente_DateExpired": "12-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 247,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_114537738492144423501",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-01-2025",
            "cliente_DateExpired": "13-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 248,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106326634503367789425",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-01-2025",
            "cliente_DateExpired": "13-11-2025",
            "cliente_sothang": 10,
            "status": 1
        },
        {
            "id": 249,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_102741520437046981882",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "13-01-2025",
            "cliente_DateExpired": "13-08-2025",
            "cliente_sothang": 7,
            "status": 1
        },
        {
            "id": 80,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_106780264751965034672",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "14-01-2025",
            "cliente_DateExpired": "14-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 94,
            "cliente_NOMBRE": "Trung Coi",
            "cliente_ID": "gg_113635103184142285292",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "14-01-2025",
            "cliente_DateExpired": "14-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 202,
            "cliente_NOMBRE": "Trung",
            "cliente_ID": "gg_101440290155708270154",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "14-01-2025",
            "cliente_DateExpired": "14-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 95,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_111909206025641851430",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "15-01-2025",
            "cliente_DateExpired": "15-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 78,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_116855036344509067577",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "16-01-2025",
            "cliente_DateExpired": "16-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 113,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_104842147937335222186",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-01-2025",
            "cliente_DateExpired": "17-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 167,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_103251523545650315122",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-01-2025",
            "cliente_DateExpired": "17-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 203,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_113889102271734982453",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "17-01-2025",
            "cliente_DateExpired": "17-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 114,
            "cliente_NOMBRE": "Nước ngoài free 1 month",
            "cliente_ID": "gg_101683985519708613795",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "18-01-2025",
            "cliente_DateExpired": "18-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 116,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106595335162396734084",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-01-2025",
            "cliente_DateExpired": "19-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 117,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_107390907235422681452",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-01-2025",
            "cliente_DateExpired": "19-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 121,
            "cliente_NOMBRE": "Gaming",
            "cliente_ID": "gg_115738724988665236299",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "19-01-2025",
            "cliente_DateExpired": "19-07-2025",
            "cliente_sothang": 6,
            "status": 1
        },
        {
            "id": 48,
            "cliente_NOMBRE": "บ่าวต้น",
            "cliente_ID": "gg_103095524597040026848",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "20-01-2025",
            "cliente_DateExpired": "20-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 123,
            "cliente_NOMBRE": "bá",
            "cliente_ID": "gg_110949810276981500985",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "21-01-2025",
            "cliente_DateExpired": "21-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 186,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101649604310275890339",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-01-2025",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 209,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_101727365115157804055",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-01-2025",
            "cliente_DateExpired": "22-04-2025",
            "cliente_sothang": 3,
            "status": 1
        },
        {
            "id": 217,
            "cliente_NOMBRE": "Nước ngoài ",
            "cliente_ID": "gg_106240130900717841289",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-01-2025",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 1,
            "status": 1
        },
        {
            "id": 42,
            "cliente_NOMBRE": "Nước Ngoài free 1 month",
            "cliente_ID": "gg_100628342387988253327",
            "Client_KeyAccecs": "XTPRIVATESKIN",
            "cliente_DateStarted": "22-01-2025",
            "cliente_DateExpired": "22-02-2025",
            "cliente_sothang": 1,
            "status": 1
        }
    ]
}
