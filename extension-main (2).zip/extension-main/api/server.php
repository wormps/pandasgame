{
    "success": true,
    "servers": [
        {
            "id": 707,
            "name": "08 .India <div id='online'></div>",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:32368/wormy",
            "status": 1
        },
        {
            "id": 706,
            "name": "07 .India ",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:30703/wormy",
            "status": 1
        },
        {
            "id": 705,
            "name": "06 .India ",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:32053/wormy",
            "status": 1
        },
        {
            "id": 704,
            "name": "05 .India <div id='online'></div>",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:32238/wormy",
            "status": 1
        },
        {
            "id": 703,
            "name": "04 .India ",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:31026/wormy",
            "status": 1
        },
        {
            "id": 702,
            "name": "03 .India ",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:30407/wormy",
            "status": 1
        },
        {
            "id": 701,
            "name": "02 .India <div id='online'></div>",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:32212/wormy",
            "status": 1
        },
        {
            "id": 700,
            "name": "01.\ud83d\udd34 YT Nona Milano<img class='team' src='https://i.imgur.com/RQTKt8G.jpeg'/><div id='online'></div>",
            "region": "australia",
            "serverUrl": "wss://mum-a.wormate.io:31211/wormy",
            "status": 1
        },
        {
            "id": 606,
            "name": "07. Wormate Friend<div id='hoat-dong'></div>",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:31091/wormy",
            "status": 1
        },
        {
            "id": 605,
            "name": "06. Wormate Friend",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:30725/wormy",
            "status": 1
        },
        {
            "id": 604,
            "name": "05. Wormate Friend",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:30161/wormy",
            "status": 1
        },
        {
            "id": 603,
            "name": "04. Wormate Friend ",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:32499/wormy",
            "status": 1
        },
        {
            "id": 602,
            "name": "03. Wormate Friend",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:30786/wormy",
            "status": 1
        },
        {
            "id": 601,
            "name": "02. Wormate Friend",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:31770/wormy",
            "status": 1
        },
        {
            "id": 600,
            "name": "01. Wormate Friend",
            "region": "japon",
            "serverUrl": "wss://tok-b.wormate.io:30171/wormy",
            "status": 1
        },
        {
            "id": 545,
            "name": "06. AU -NEW<img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "granbretana",
            "serverUrl": "wss://dal-b.wormate.io:31163/wormy",
            "status": 1
        },
        {
            "id": 544,
            "name": "05. AU - NEW<img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "granbretana",
            "serverUrl": "wss://sin-a.wormate.io:31510/wormy",
            "status": 1
        },
        {
            "id": 544,
            "name": "04. AU - SV VIP<img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "granbretana",
            "serverUrl": "wss://syd-a.wormate.io:31882/wormy",
            "status": 1
        },
        {
            "id": 542,
            "name": "03. \ud83e\udd55 KTR Gaming<img class='team' src='https://haylamday.com/images/team/kiss-the-rain.PNG'/> ",
            "region": "granbretana",
            "serverUrl": "wss://syd-a.wormate.io:31882/wormy",
            "status": 1
        },
        {
            "id": 541,
            "name": "02. AU - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='hoat-dong'></div>",
            "region": "granbretana",
            "serverUrl": "wss://syd-a.wormate.io:31238/wormy",
            "status": 1
        },
        {
            "id": 540,
            "name": "01.\ud83d\udd34 YT Nona Milano<img class='team' src='https://i.imgur.com/RQTKt8G.jpeg'/><div id='hoat-dong'></div>",
            "region": "granbretana",
            "serverUrl": "wss://syd-a.wormate.io:31342/wormy",
            "status": 1
        },
        {
            "id": 473,
            "name": "04. UAE - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='hoat-dong'></div>",
            "region": "mexico",
            "serverUrl": "wss://dxb-a.wormate.io:31353/wormy",
            "status": 1
        },
        {
            "id": 473,
            "name": "03. SAG - Ali Gaming <img class='team' src='https://haylamday.com/images/team/aligaming.JPG'/><div id='hoat-dong'></div><div id='online'></div>",
            "region": "mexico",
            "serverUrl": "wss://dxb-a.wormate.io:32703/wormy",
            "status": 1
        },
        {
            "id": 472,
            "name": "02. FIRE@YT\ud83d\udd25 <img class='team' src='https://haylamday.com/images/team/fire.JPG'/> <div id='online'></div>",
            "region": "mexico",
            "serverUrl": "wss://dxb-a.wormate.io:31975/wormy",
            "status": 1
        },
        {
            "id": 470,
            "name": "01.\ud83d\udd34 YT Nona Milano<img class='team' src='https://i.imgur.com/RQTKt8G.jpeg'/> <div id='online'></div>",
            "region": "mexico",
            "serverUrl": "wss://dxb-a.wormate.io:32703/wormy",
            "status": 1
        },
        {
            "id": 414,
            "name": "15. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32465/wormy",
            "status": 1
        },
        {
            "id": 413,
            "name": "14. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32500/wormy",
            "status": 1
        },
        {
            "id": 412,
            "name": "13. Lithuania <div id='online'></div>",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32368/wormy",
            "status": 1
        },
        {
            "id": 411,
            "name": "12. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:30407/wormy",
            "status": 1
        },
        {
            "id": 410,
            "name": "11. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:30332/wormy",
            "status": 1
        },
        {
            "id": 409,
            "name": "10. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:31516/wormy",
            "status": 1
        },
        {
            "id": 408,
            "name": "09. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:31311/wormy",
            "status": 1
        },
        {
            "id": 407,
            "name": "08. Lithuania</div<div id='online'></div>",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:30165/wormy",
            "status": 1
        },
        {
            "id": 406,
            "name": "07. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:31142/wormy",
            "status": 1
        },
        {
            "id": 405,
            "name": "06. Lithuania </div",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:31026/wormy",
            "status": 1
        },
        {
            "id": 404,
            "name": "05. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:30703/wormy",
            "status": 1
        },
        {
            "id": 403,
            "name": "04. Lithuania</div<div id='online'></div>",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32212/wormy",
            "status": 1
        },
        {
            "id": 402,
            "name": "03. Lithuania ",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32053/wormy",
            "status": 1
        },
        {
            "id": 401,
            "name": "02. Lithuania </div<div id='online'></div>",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:31211/wormy",
            "status": 1
        },
        {
            "id": 400,
            "name": "01. Lithuania <div id='online'></div>",
            "region": "canada",
            "serverUrl": "wss://vin-a.wormate.io:32368/wormy",
            "status": 1
        },
        {
            "id": 288,
            "name": "18. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:30171/wormy",
            "status": 1
        },
        {
            "id": 287,
            "name": "17. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:30392/wormy",
            "status": 1
        },
        {
            "id": 286,
            "name": "16. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31975/wormy",
            "status": 1
        },
        {
            "id": 285,
            "name": "15. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:32703/wormy",
            "status": 1
        },
        {
            "id": 284,
            "name": "14. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:30809/wormy",
            "status": 1
        },
        {
            "id": 283,
            "name": "13. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://dal-b.wormate.io:31555/wormy",
            "status": 1
        },
        {
            "id": 282,
            "name": "12. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://vin-a.wormate.io:32638/wormy",
            "status": 1
        },
        {
            "id": 281,
            "name": "11. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31106/wormy",
            "status": 1
        },
        {
            "id": 280,
            "name": "10. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31091/wormy",
            "status": 1
        },
        {
            "id": 279,
            "name": "09. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31975/wormy",
            "status": 1
        },
        {
            "id": 278,
            "name": "08. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://dal-b.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 27,
            "name": "07. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 276,
            "name": "06. Brazil  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "germania",
            "serverUrl": "wss://dal-b.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 275,
            "name": "05. Brasil - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 274,
            "name": "04. Brasil - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31713/wormy",
            "status": 1
        },
        {
            "id": 273,
            "name": "03. Brasil - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 272,
            "name": "02. Brasil - WFC<img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:31713/wormy",
            "status": 1
        },
        {
            "id": 271,
            "name": "01. Guizeira  <img class='team' src='https://haylamday.com/images/team/Guizeira.jpg'/> <div id='online'></div>",
            "region": "germania",
            "serverUrl": "wss://sao-a.wormate.io:30560/wormy",
            "status": 1
        },
        {
            "id": 217,
            "name": "18. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:30909/wormy",
            "status": 1
        },
        {
            "id": 216,
            "name": "17. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:30265/wormy",
            "status": 1
        },
        {
            "id": 215,
            "name": "16. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 214,
            "name": "15. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31695/wormy",
            "status": 1
        },
        {
            "id": 213,
            "name": "14. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31819/wormy",
            "status": 1
        },
        {
            "id": 212,
            "name": "13. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:31392/wormy",
            "status": 1
        },
        {
            "id": 211,
            "name": "12. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:30106/wormy",
            "status": 1
        },
        {
            "id": 210,
            "name": "11. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:30140/wormy",
            "status": 1
        },
        {
            "id": 209,
            "name": "10. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:32054/wormy",
            "status": 1
        },
        {
            "id": 208,
            "name": "09. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 207,
            "name": "08. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 206,
            "name": "07. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:30106/wormy",
            "status": 1
        },
        {
            "id": 205,
            "name": "06. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://fra-c.wormate.io:31695/wormy",
            "status": 1
        },
        {
            "id": 204,
            "name": "05. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://dal-b.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 203,
            "name": "04. FR - WFC <img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 202,
            "name": "03. Mido Gaming <img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 201,
            "name": "02. KURDISTAN <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:32054/wormy",
            "status": 1
        },
        {
            "id": 200,
            "name": "01.\ud83d\udd34 YT Nona Milano<img class='team' src='https://i.imgur.com/RQTKt8G.jpeg'/> <div id='online'></div>",
            "region": "francia",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 175,
            "name": "36. WFC - VTH<img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31203/wormy",
            "status": 1
        },
        {
            "id": 174,
            "name": "35. WFC - VTH<img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31353/wormy",
            "status": 1
        },
        {
            "id": 173,
            "name": "34. WFC - VTH<img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-b.wormate.io:31510/wormy",
            "status": 1
        },
        {
            "id": 172,
            "name": "33. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-b.wormate.io:31534/wormy",
            "status": 1
        },
        {
            "id": 171,
            "name": "32. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-b.wormate.io:32677/wormy",
            "status": 1
        },
        {
            "id": 170,
            "name": "31. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-b.wormate.io:30165/wormy",
            "status": 1
        },
        {
            "id": 169,
            "name": "30. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32577/wormy",
            "status": 1
        },
        {
            "id": 168,
            "name": "29. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32405/wormy",
            "status": 1
        },
        {
            "id": 167,
            "name": "28. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31908/wormy",
            "status": 1
        },
        {
            "id": 166,
            "name": "27. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 165,
            "name": "26. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 164,
            "name": "25. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31533/wormy",
            "status": 1
        },
        {
            "id": 163,
            "name": "24. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31230/wormy",
            "status": 1
        },
        {
            "id": 162,
            "name": "23. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31163/wormy",
            "status": 1
        },
        {
            "id": 161,
            "name": "22. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31091/wormy",
            "status": 1
        },
        {
            "id": 160,
            "name": "21. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31084/wormy",
            "status": 1
        },
        {
            "id": 159,
            "name": "20. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30809/wormy",
            "status": 1
        },
        {
            "id": 158,
            "name": "19. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30657/wormy",
            "status": 1
        },
        {
            "id": 157,
            "name": "18. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30725/wormy",
            "status": 1
        },
        {
            "id": 156,
            "name": "17. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30702/wormy",
            "status": 1
        },
        {
            "id": 155,
            "name": "16. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31339/wormy",
            "status": 1
        },
        {
            "id": 154,
            "name": "15. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30371/wormy",
            "status": 1
        },
        {
            "id": 153,
            "name": "14. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30339/wormy",
            "status": 1
        },
        {
            "id": 152,
            "name": "13. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30327/wormy",
            "status": 1
        },
        {
            "id": 151,
            "name": "12. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30208/wormy",
            "status": 1
        },
        {
            "id": 150,
            "name": "11. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30171/wormy",
            "status": 1
        },
        {
            "id": 149,
            "name": "10. WFC - VTH <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30161/wormy",
            "status": 1
        },
        {
            "id": 148,
            "name": "09. \u1d40\u1d9c\u1d40\u2c7d Tu\u1ea5n C\u1ea3nh TV<img class='team' src='https://haylamday.com/images/team/tuancanh.jpg'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 147,
            "name": "08. TEAM \ud83d\udc4b\ud83d\udc4b ARC <img class='team' src='https://haylamday.com/images/team/team_arc.jpg'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30573/wormy",
            "status": 1
        },
        {
            "id": 146,
            "name": "07. Kiss The Rain<img class='team' src='https://haylamday.com/images/team/kiss-the-rain.PNG'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32500/wormy",
            "status": 1
        },
        {
            "id": 145,
            "name": "06. \u0110\u1ecbnh M\u1ec7nh Bigo<img class='team' src='https://haylamday.com/images/team/dinh-menh-bigo.PNG'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32212/wormy",
            "status": 1
        },
        {
            "id": 144,
            "name": "05. TH\u01af K\u00dd BIGO <img class='team' src='https://haylamday.com/images/team/thuky.png'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:32053/wormy",
            "status": 1
        },
        {
            "id": 143,
            "name": "04. Sen \u0110\u00e1 Gaming<img class='team' src='https://haylamday.com/images/team/sen_da.jpg'/> <div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31211/wormy",
            "status": 1
        },
        {
            "id": 142,
            "name": "03. \ud83c\udd85\ud83c\udd7d\ud83c\udf0dHo\u00e0ng H\u00e0<img class='team' src='https://haylamday.com/images/team/hoang-ha.PNG'/> ",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31026/wormy",
            "status": 1
        },
        {
            "id": 141,
            "name": "02. \ud83c\udd85\ud83c\udd7d\ud83c\udf0d\u0f3a\u2112\u1eef\u0f12\u212c\u1ed1\u0f3b <img class='team' src='https://haylamday.com/images/team/trong-hoan.jpg'/>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:30703/wormy",
            "status": 1
        },
        {
            "id": 140,
            "name": "01.\ud83c\udf52 Cherry Land <img class='team' src='https://haylamday.com/images/team/cheryy.PNG'/><div id='online'></div>",
            "region": "singapur",
            "serverUrl": "wss://sin-a.wormate.io:31764/wormy",
            "status": 1
        },
        {
            "id": 110,
            "name": "41. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30725/wormy",
            "status": 1
        },
        {
            "id": 109,
            "name": "40. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://dal-b.wormate.io:30809/wormy",
            "status": 1
        },
        {
            "id": 108,
            "name": "39. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:32500/wormy",
            "status": 1
        },
        {
            "id": 107,
            "name": "38. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://sao-a.wormate.io:31163/wormy",
            "status": 1
        },
        {
            "id": 106,
            "name": "37. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:32212/wormy",
            "status": 1
        },
        {
            "id": 105,
            "name": "36. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:32053/wormy",
            "status": 1
        },
        {
            "id": 104,
            "name": "35. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:31516/wormy",
            "status": 1
        },
        {
            "id": 103,
            "name": "34. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:31311/wormy",
            "status": 1
        },
        {
            "id": 102,
            "name": "33. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> <div id='online'></div>",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:31211/wormy",
            "status": 1
        },
        {
            "id": 101,
            "name": "32. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:31142/wormy",
            "status": 1
        },
        {
            "id": 100,
            "name": "31. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:31026/wormy",
            "status": 1
        },
        {
            "id": 99,
            "name": "30. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:30703/wormy",
            "status": 1
        },
        {
            "id": 98,
            "name": "29. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32746/wormy",
            "status": 1
        },
        {
            "id": 97,
            "name": "28. US<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:30332/wormy",
            "status": 1
        },
        {
            "id": 96,
            "name": "27. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30208/wormy",
            "status": 1
        },
        {
            "id": 95,
            "name": "26. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://sin-a.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 94,
            "name": "25. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:30407/wormy",
            "status": 1
        },
        {
            "id": 93,
            "name": "24. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:31555/wormy",
            "status": 1
        },
        {
            "id": 92,
            "name": "23. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:31000/wormy",
            "status": 1
        },
        {
            "id": 91,
            "name": "22. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://sao-a.wormate.io:30072/wormy",
            "status": 1
        },
        {
            "id": 90,
            "name": "21. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://dal-b.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 89,
            "name": "20. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30296/wormy",
            "status": 1
        },
        {
            "id": 88,
            "name": "19. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32746/wormy",
            "status": 1
        },
        {
            "id": 87,
            "name": "18. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30042/wormy",
            "status": 1
        },
        {
            "id": 86,
            "name": "17. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32214/wormy",
            "status": 1
        },
        {
            "id": 85,
            "name": "16. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32091/wormy",
            "status": 1
        },
        {
            "id": 84,
            "name": "15. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:31279/wormy",
            "status": 1
        },
        {
            "id": 83,
            "name": "14. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30536/wormy",
            "status": 1
        },
        {
            "id": 82,
            "name": "13. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30162/wormy",
            "status": 1
        },
        {
            "id": 81,
            "name": "12. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32746/wormy",
            "status": 1
        },
        {
            "id": 80,
            "name": "11. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30296/wormy",
            "status": 1
        },
        {
            "id": 78,
            "name": "10. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32111/wormy",
            "status": 1
        },
        {
            "id": 78,
            "name": "09. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:32465/wormy",
            "status": 1
        },
        {
            "id": 77,
            "name": "08. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32403/wormy",
            "status": 1
        },
        {
            "id": 76,
            "name": "07. US <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:32111/wormy",
            "status": 1
        },
        {
            "id": 75,
            "name": "06. US  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30296/wormy",
            "status": 1
        },
        {
            "id": 74,
            "name": "05. LEMANZ <img class='team' src='https://haylamday.com/images/team/LEMANZ.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://hil-a.wormate.io:30162/wormy",
            "status": 1
        },
        {
            "id": 73,
            "name": "04. LUCKY GAMING<img class='team' src='https://haylamday.com/images/team/luckyg.jpg'/><div id='online'></div>",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:32368/wormy",
            "status": 1
        },
        {
            "id": 72,
            "name": "03. CD TEAM  <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "eeuu",
            "serverUrl": "wss://dal-b.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 71,
            "name": "02. TEAM \ud83d\udc4b\ud83d\udc4b ARC <img class='team' src='https://haylamday.com/images/team/team_arc.jpg'/>",
            "region": "eeuu",
            "serverUrl": "wss://dal-b.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 70,
            "name": "01.\ud83d\udd34 YT Nona Milano<img class='team' src='https://i.imgur.com/RQTKt8G.jpeg'/> ",
            "region": "eeuu",
            "serverUrl": "wss://vin-a.wormate.io:30407/wormy",
            "status": 1
        },
        {
            "id": 62,
            "name": "62.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32650/wormy",
            "status": 1
        },
        {
            "id": 61,
            "name": "61.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32703/wormy",
            "status": 1
        },
        {
            "id": 60,
            "name": "60.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 59,
            "name": "59.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30106/wormy",
            "status": 1
        },
        {
            "id": 58,
            "name": "58.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30245/wormy",
            "status": 1
        },
        {
            "id": 57,
            "name": "57.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://dal-b.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 56,
            "name": "56.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://hil-a.wormate.io:30213/wormy",
            "status": 1
        },
        {
            "id": 55,
            "name": "55.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://vin-a.wormate.io:30703/wormy",
            "status": 1
        },
        {
            "id": 54,
            "name": "54.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32611/wormy",
            "status": 1
        },
        {
            "id": 53,
            "name": "53.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31859/wormy",
            "status": 1
        },
        {
            "id": 52,
            "name": "52.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30339/wormy",
            "status": 1
        },
        {
            "id": 51,
            "name": "51.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31123/wormy",
            "status": 1
        },
        {
            "id": 50,
            "name": "50.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30161/wormy",
            "status": 1
        },
        {
            "id": 49,
            "name": "49.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32577/wormy",
            "status": 1
        },
        {
            "id": 48,
            "name": "48.  De SERVER <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32405/wormy",
            "status": 1
        },
        {
            "id": 47,
            "name": "47.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31908/wormy",
            "status": 1
        },
        {
            "id": 46,
            "name": "46.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30327/wormy",
            "status": 1
        },
        {
            "id": 45,
            "name": "45.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30909/wormy",
            "status": 1
        },
        {
            "id": 44,
            "name": "44.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31230/wormy",
            "status": 1
        },
        {
            "id": 43,
            "name": "43.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31163/wormy",
            "status": 1
        },
        {
            "id": 42,
            "name": "42.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31091/wormy",
            "status": 1
        },
        {
            "id": 41,
            "name": "41.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31084/wormy",
            "status": 1
        },
        {
            "id": 40,
            "name": "40.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30809/wormy",
            "status": 1
        },
        {
            "id": 39,
            "name": "39.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30135/wormy",
            "status": 1
        },
        {
            "id": 38,
            "name": "38.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30725/wormy",
            "status": 1
        },
        {
            "id": 37,
            "name": "37.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32584/wormy",
            "status": 1
        },
        {
            "id": 36,
            "name": "36.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31695/wormy",
            "status": 1
        },
        {
            "id": 35,
            "name": "35.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32054/wormy",
            "status": 1
        },
        {
            "id": 34,
            "name": "34.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30171/wormy",
            "status": 1
        },
        {
            "id": 33,
            "name": "33.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 32,
            "name": "32.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 31,
            "name": "31.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 30,
            "name": "30.  De SERVER <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31695/wormy",
            "status": 1
        },
        {
            "id": 29,
            "name": "29.  De SERVER <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32054/wormy",
            "status": 1
        },
        {
            "id": 28,
            "name": "28.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30171/wormy",
            "status": 1
        },
        {
            "id": 27,
            "name": "27.  De SERVER<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 26,
            "name": "26.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31819/wormy",
            "status": 1
        },
        {
            "id": 25,
            "name": "25.  De SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31533/wormy",
            "status": 1
        },
        {
            "id": 24,
            "name": "24.  DE SERVER <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32054/wormy",
            "status": 1
        },
        {
            "id": 23,
            "name": "23.  DE SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30208/wormy",
            "status": 1
        },
        {
            "id": 22,
            "name": "22.  DE SERVER    <img class='team' src='https://haylamday.com/images/team/wfc.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 21,
            "name": "21.  DE SERVER<img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://gra-a.wormate.io:31819/wormy",
            "status": 1
        },
        {
            "id": 20,
            "name": "20.  \ud83d\udc51EFFENDI\ud83d\udc51    <img class='team' src='https://haylamday.com/images/team/eff.jpg'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30208/wormy",
            "status": 1
        },
        {
            "id": 19,
            "name": "19. IRAQ <img class='team' src='https://haylamday.com/images/team/wfc.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31819/wormy",
            "status": 1
        },
        {
            "id": 18,
            "name": "18.MAZARAT <img class='team' src='https://haylamday.com/images/team/mazarat.jpg'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31533/worm",
            "status": 1
        },
        {
            "id": 17,
            "name": "17. NCN <img class='team' src='https://haylamday.com/images/team/ncn.jpg'/> ",
            "serverUrl": "wss://fra-c.wormate.io:30339/wormy",
            "status": 1
        },
        {
            "id": 16,
            "name": "16. IRAQ <img class='team' src='https://haylamday.com/images/team/brazil.png'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30265/wormy",
            "status": 1
        },
        {
            "id": 15,
            "name": "15. ZIKO GAMING <img class='team' src='https://haylamday.com/images/team/zikogaming.jpeg'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30106/wormy",
            "status": 1
        },
        {
            "id": 14,
            "name": "14. MARSHMELO GAMING <img class='team' src='https://haylamday.com/images/team/marsh.jpg'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 13,
            "name": "13. RIO GAMING <img class='team' src='https://haylamday.com/images/team/riogaming.jpg'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://gra-a.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 12,
            "name": "12. DZ GAMING <img class='team' src='https://haylamday.com/images/team/dz.jpg'/>  ",
            "region": "peru",
            "serverUrl": "wss://gra-a.wormate.io:30245/wormy",
            "status": 1
        },
        {
            "id": 11,
            "name": "11. BSG  <img class='team' src='https://haylamday.com/images/team/bsg.jpg'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:32581/wormy",
            "status": 1
        },
        {
            "id": 10,
            "name": "10. REEM GAMING <img class='team' src='https://haylamday.com/images/team/reem.png'/> <div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 9,
            "name": "19. \u0627\u064a\u062a\u0645\u0627\u0643 - AitMak\u200e  <img class='team' src='https://haylamday.com/images/team/aitmak.jpg'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31038/wormy",
            "status": 1
        },
        {
            "id": 8,
            "name": "08. \u0627\u0628\u0646 \u0627\u0644\u0634\u0627\u0645 <img class='team' src='https://haylamday.com/images/team/abnsham.jpg'/> ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30106/wormy",
            "status": 1
        },
        {
            "id": 7,
            "name": "07. Glitch <img class='team' src='https://haylamday.com/images/team/show.jpg'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31392/wormy",
            "status": 1
        },
        {
            "id": 6,
            "name": "06. \u0627\u0628\u0646 \u0646\u064a\u0646\u0648\u0649 Gaming<img class='team' src='https://haylamday.com/images/team/ninawa.jpg'/>  <div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 5,
            "name": "05. EZI MIRAN <img class='team' src='https://haylamday.com/images/team/EZIDXAN.png'/>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:31750/wormy",
            "status": 1
        },
        {
            "id": 4,
            "name": "04. Kurdo 101 Gaming <img class='team' src='https://haylamday.com/images/team/101kurdo.png'/><div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 3,
            "name": "03. KURDISTAN 75 <img class='team' src='https://haylamday.com/images/team/kurdistan75.jpg'/>    ",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30702/wormy",
            "status": 1
        },
        {
            "id": 2,
            "name": "02.\ud83d\udd34 YT Seko⚡v4<img class='team' src='https://i.imgur.com/FIme4PC.png'/> <div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        },
        {
            "id": 1,
            "name": "01.\ud83d\udd34 YT PANDAX<img class='team' src='https://i.imgur.com/FUOpj53.png'/> <div id='online'></div>",
            "region": "peru",
            "serverUrl": "wss://fra-c.wormate.io:30055/wormy",
            "status": 1
        }
    ]
}
